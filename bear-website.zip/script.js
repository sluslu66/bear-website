function showBear() {
    const bears = [
        "🐻 Brown Bear says hello!",
        "❄️ Polar Bear from the Arctic!",
        "🌲 Black Bear in the forest!",
        "🍯 Panda enjoying bamboo!"
    ];
    const random = bears[Math.floor(Math.random() * bears.length)];
    document.getElementById("bear").innerText = random;
}
